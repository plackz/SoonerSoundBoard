/* main.js */
/* play function. to play music files */
function play(){
  var audio = document.getElementById("audio");
  audio.play();
}

function pause(){
  var audio = document.getElementById("audio");
  audio.pause();
}

function play1(){
  var audio1 = document.getElementById("audio1");
  audio1.play();
}

function pause1(){
  var audio1 = document.getElementById("audio1");
  audio1.pause();
}

function play2(){
  var audio2 = document.getElementById("audio2");
  audio2.play();
}

function pause2(){
  var audio2 = document.getElementById("audio2");
  audio2.pause();
}

function play3(){
  var audio3 = document.getElementById("audio3");
  audio3.play();
}

function pause3(){
  var audio3 = document.getElementById("audio3");
  audio3.pause();
}

function play4(){
  var audio4 = document.getElementById("audio4");
  audio4.play();
}

function pause4(){
  var audio4 = document.getElementById("audio4");
  audio4.pause();
}